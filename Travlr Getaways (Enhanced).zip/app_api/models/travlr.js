const mongoose = require('mongoose'); 

// Define the trip schema with enhancements and validation
const tripSchema = new mongoose.Schema({ 
    code: { 
        type: String,
        required: true,
        index: true,
        maxlength: 10 // Limits code for length consistency
    },
    name: { 
        type: String,
        required: true,
        index: true,
        maxlength: 100 // Enforces a max length 
    },
    length: {
        type: String,
        required: true
    }, 
    start: { 
        type: Date,
        required: true,
        validate: {
            validator: function(value) {
                return value > new Date(); // Makes sure trip starts in the future
            },
            message: 'Trip start date must be in the future.'
        }
    }, 
    resort: { 
        type: String,
        required: true,
        maxlength: 100 // Prevents long resort names
    }, 
    perPerson: { 
        type: String,
        required: true
    }, 
    image: { 
        type: String,
        required: true,
        match: /^https?:\/\/.*\.(jpg|jpeg|png|gif)$/i // Regex for image URLs
    }, 
    description: { 
        type: String, 
        required: true,
        maxlength: 500 // Keeps description concise and readable
    } 
}); 

const Trip = mongoose.model('trips', tripSchema); 
module.exports = Trip; 