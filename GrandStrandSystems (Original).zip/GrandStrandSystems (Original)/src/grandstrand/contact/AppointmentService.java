package grandstrand.contact;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	private Map<String, Appointment> appointments;
	
	public AppointmentService() {
		appointments = new HashMap<>();
	}
	
	// Add a new appointment
	public boolean addAppointment(Appointment appointment) {
			if (appointments.containsKey(appointment.getAppointmentID())) {
				throw new IllegalArgumentException("Appoint ID Already Exists");
			}
			appointments.put(appointment.getAppointmentID(), appointment);
			return true;
	}
	
	// Delete an appointment by ID
	public void deleteAppointment(String appointmentID) {
		if (!appointments.containsKey(appointmentID)) {
			throw new IllegalArgumentException("Appointment ID Not Found");
		}
		appointments.remove(appointmentID);
	}
	
	// Find an appointment by ID
	public Appointment getAppointment(String appointmentID) {
		return appointments.get(appointmentID);
	}
	
	// Update an appointment description
	public void updateDescription(String appointmentID, String newDescription) {
		Appointment appointment = getAppointment(appointmentID);
		if (appointment == null) {
			throw new IllegalArgumentException("Apoint ID Not Found");
		}
		appointment.setDescription(newDescription);
	}
	
}
