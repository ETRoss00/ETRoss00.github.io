package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import grandstrand.contact.Task;
import grandstrand.contact.TaskService;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
	
	private TaskService taskService;
	
	@BeforeEach
	public void setup() {
		taskService = new TaskService();
	}
	
	// Test adding a task
	@Test
	public void testAddTask() {
		Task task = new Task("12345", "Task Name", "Task Description");
		assertTrue(taskService.addTask(task));
		assertNotNull(taskService.getTask("12345"));
	}
	
	// Test adding a task with duplicate ID
	@Test
	public void testAddTaskWithDuplicateID() {
		Task task1 = new Task("12345", "Task Name", "Task Description");
		Task task2 = new Task("12345", "Task Name 2", "Task Description 2");
		taskService.addTask(task1);
		assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
	}
	
	// Test deleting a task
	@Test
	public void testDeleteTask() {
		Task task = new Task("12345", "Task Name", "Task Description");
		taskService.addTask(task);
		taskService.deleteTask("12345");
		assertNull(taskService.getTask("123454"));
	}
	
	// Test deleting a task that doesn't exist
    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("00000"));
    }
	
	// Test updating a valid task name
	@Test
	public void testUpdateValidTaskName() {
		Task task = new Task("12345", "Task Name", "Task Description");
		taskService.addTask(task);
		taskService.updateTaskName("12345", "New Name");
		
		Task updatedTask = taskService.getTask("12345");
		assertEquals("New Name", updatedTask.getName());
	}
	
	// Test updating an invalid task name length
	@Test
	public void testUpdateInvalidTaskNameLength() {
		Task task = new Task("12345", "Task Name", "Task Description");
		taskService.addTask(task);
		assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("12345", "This Name is Too Long"));
	}
	
	// Test updating a valid task description
	@Test
	public void testUpdateValidTaskDescription() {
		Task task = new Task("12345", "Task Name", "Task Description");
		taskService.addTask(task);
		taskService.updateTaskDescription("12345", "New Description");
		
		Task updatedTask = taskService.getTask("12345");
		assertEquals("New Description", updatedTask.getDescription());
	}
	
	// Test updating an invalid task description length
	@Test
	public void testUpdateInvalidTaskDescriptionLength() {
		Task task = new Task("12345", "Task Name", "Task Description");
		taskService.addTask(task);
		assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("12345", "This Task Description is Way Too Long and Should Throw an Exception"));
	}
	
	// Test updating a task that doesn't exist
	@Test
	public void testUpdateNonexistentTask() {
		assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("00000", "New Name"));
	}
}
