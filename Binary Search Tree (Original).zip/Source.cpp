#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

// Define structure for Course
struct Course {
	string courseNumber;
	string courseName;
	vector<string> prerequisites;
};

// Define structure for BST node
struct BSTNode {
	Course course;
	BSTNode* left;
	BSTNode* right;
	BSTNode(Course c) : course(c), left(nullptr), right(nullptr) {}
};

// Function to insert a course into BST
BSTNode* insertIntoBST(BSTNode* node, Course course) {
	if (node == nullptr) {
		return new BSTNode(course);
	}
	if (course.courseNumber < node->course.courseNumber) {
		node->left = insertIntoBST(node->left, course);
	}
	else {
		node->right = insertIntoBST(node->right, course);
	}
	return node;
}

// Function to load data into BST
BSTNode* loadData(string filename) {
	ifstream courseFile(filename);
	string line;
	BSTNode* root = nullptr;

	if (courseFile.is_open()) {
		while (getline(courseFile, line)) {
			stringstream ss(line);
			string courseNumber;
			string name;
			string prerequisite;
			getline(ss, courseNumber, ',');
			getline(ss, name, ',');

			Course newCourse;
			newCourse.courseNumber = courseNumber;
			newCourse.courseName = name;

			while (getline(ss, prerequisite, ',')) {
				newCourse.prerequisites.push_back(prerequisite);
			}

			root = insertIntoBST(root, newCourse);
		}
		courseFile.close();
	}
	else {
		cout << "unable to open file." << endl;
		return nullptr;
	}
	return root;
}

// Function to print course in order
void printCourses(BSTNode* node) {
	if (node != nullptr) {
		printCourses(node->left);
		cout << node->course.courseNumber << ", " << node->course.courseName << endl;
		printCourses(node->right);
	}
}

// Function to search and print course details
void searchAndPrintCourse(BSTNode* node, string courseNumber) {
	while (node != nullptr) {
		if (courseNumber == node->course.courseNumber) {
			cout << node->course.courseNumber << ", " << node->course.courseName << endl;
			if (!node->course.prerequisites.empty()) {
				cout << "Prerequisites: ";
				for (const string& prerequisite : node->course.prerequisites) {
					cout << prerequisite << " ";
				}
				cout << endl;
			}
			else {
				cout << "No prerequisites" << endl;
			}
			return;
		}
		else if (courseNumber < node->course.courseNumber) {
			node = node->left;
		}
		else {
			node = node->right;
		}
	}
	cout << "Course not found" << endl;
}

// Main menu
int main() {
	BSTNode* root = nullptr;
	int userInput;
	string filename;
	string courseNumber;
	
	do {
		// Display menu options
		cout << "1. Load Data Structure." << endl;
		cout << "2. Print Course List." << endl;
		cout << "3. Print Course." << endl;
		cout << "9. Exit." << endl;
		cout << "What would you like to do?";
		cin >> userInput;

		// Handle menu options
		switch (userInput) {
		case 1:
			cout << "Enter filename: ";
			cin.ignore();	// Clear any leftover newline characters
			getline(cin, filename);
			root = loadData(filename);
			if (root != nullptr) {
				cout << "Data loaded successfully." << endl;
			}
			else {
				cout << "Data loading failed." << endl;
			}
			break;

		case 2:
			if (root != nullptr) {
				cout << "Courses in alphanumerical order: " << endl;
				printCourses(root);
			}
			else {
				cout << "No data loaded." << endl;
			}
			break;

		case 3:
			cout << "Enter course number: ";
			cin >> courseNumber;
			searchAndPrintCourse(root, courseNumber);
			break;

		case 9:
			cout << "Exiting program" << endl;
			break;

		default:
			cout << "Invalid option. Please try again." << endl;
		}

	} while (userInput != 9);

	return 0;
}