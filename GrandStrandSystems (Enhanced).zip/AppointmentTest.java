package test;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

import grandstrand.contact.Appointment;

public class AppointmentTest {
	
	// Test creation of a valid appointment
	@Test
	public void testValidAppointmentCreation() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000); // Future date
		Appointment appointment = new Appointment("12345", futureDate, "Doctor Appointment"); 
		
		assertEquals("12345", appointment.getAppointmentID());
		assertEquals(futureDate, appointment.getAppointmentDate());
		assertEquals("Doctor Appointment", appointment.getDescription());
	}
	
	// Test invalid appointment ID length
	@Test
	public void testInvalidAppointmentIDLength() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		assertThrows(IllegalArgumentException.class, () ->
			new Appointment("123456789011", futureDate, "Doctor Appointment"));
	}
	
	// Test invalid appointment date
	@Test
	public void testInvalidAppointmentDate() {
		Date pastDate = new Date(System.currentTimeMillis() - 1000); // Past date
		assertThrows(IllegalArgumentException.class, () ->
			new Appointment("12345", pastDate, "Doctor Appointment"));
	}
	
	// Test invalid appointment description length
	@Test
	public void testInvalidAppointmentDescriptionLength() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		assertThrows(IllegalArgumentException.class, () ->
			new Appointment("12345", futureDate, "This Description is Too Long and Should Throw an Exception"));
	}
}
