package test;

import org.junit.jupiter.api.Test;

import grandstrand.contact.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

	// Test creation of valid task
	@Test
	public void testValidTaskCreation() {
		Task task = new Task("12345", "Task Name", "Task Description");
		assertEquals("12345", task.getTaskID());
		assertEquals("Task Name", task.getName()); 
		assertEquals("Task Description", task.getDescription());
	}
	
	// Test invalid task ID length
	@Test
	public void testInvalidTaskIDLength() {
		assertThrows(IllegalArgumentException.class, () ->
		new Task("123456789012", "Task Name", "Task Description"));
	}
	
	// Test invalid name length
	@Test
	public void testInvalidNameLength() {
		assertThrows(IllegalArgumentException.class, () ->
		new Task("12345", "This name is too long", "Task Description"));
	}
	
	// Test invalid description length
	@Test
	public void testInvalidDescriptionLength() {
		assertThrows(IllegalArgumentException.class, () ->
		new Task("12345", "Task Name", "This description is way too long and should throw an exception"));
	}
	
	// Test updating the name
	@Test
	public void testSetName() {
		Task task = new Task("12345", "Task Name", "Task Description");
		task.setName("New Name");
		assertEquals("New Name", task.getName());
	}
	
	// Test setting invalid name length
	@Test
	public void testSetInvalidNameLength() {
		Task task = new Task("12345", "Task Name", "Task Description");
		assertThrows(IllegalArgumentException.class, () -> task.setName("This name is too long"));
	}
	
	// Test updating the description
	@Test
	public void testSetDescription() {
		Task task = new Task("12345", "Task Name", "Task Description");
		task.setDescription("New Description");
		assertEquals("New Description", task.getDescription());
	}
	
	// Test setting invalid description length
	@Test
	public void testSetInvalidDescriptionLength() {
		Task task = new Task("12345", "Task Name", "Task Description");
		assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is way too long and should throw an exception"));
	}
}
