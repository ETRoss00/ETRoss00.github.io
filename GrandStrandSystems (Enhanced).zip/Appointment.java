package grandstrand.contact;

import java.util.Date;

import grandstrand.util.ValidateInput;

public class Appointment {
	private final String appointmentID;
	private final Date appointmentDate;
	private String description;
	
	// Constructor for valid attributes
	public Appointment(String appointmentID, Date appointmentDate, String description) {
		if (!ValidateInput.isValidId(appointmentID, 10)) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		/*if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}*/
		if (!ValidateInput.isValidFutureDate(appointmentDate)) {
	        throw new IllegalArgumentException("Invalid Appointment Date");
	    }
		if (!ValidateInput.isValidDescription(description, 50)) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}
	
	/*// Method to validate input
	private boolean validateInput(String input, int length) {
		return (input != null && input.length() <= length);
	}*/
	
	// Getters
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}
	
	// Setter for updateable description
	public void setDescription(String description) {
		if (!ValidateInput.isValidDescription(description, 50)) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}
}
