package grandstrand.contact;

import java.util.HashMap;
import java.util.Map;


public class TaskService {
	// Hash map to store tasks
	private Map<String, Task> tasks;
	
	// Constructor to initialize task service
	public TaskService() {
		tasks = new HashMap<>();
	}
	
	// Add a new task
	public boolean addTask(Task task) {
		if (tasks.containsKey(task.getTaskID())) {
			throw new IllegalArgumentException("Task ID Already Exists");
		}
		tasks.put(task.getTaskID(), task);
		return true;
	}
	
	// Delete a task
	public void deleteTask(String taskID) {
		if(!tasks.containsKey(taskID)) {
			throw new IllegalArgumentException("Task ID Not Found");
		}
		tasks.remove(taskID);
	}
	
	// Retrieve task by ID
	public Task getTask(String taskID) {
		return tasks.get(taskID);
	}
	
	// Update task name
	public void updateTaskName(String taskID, String newName) {
		Task task = getTask(taskID);
		if (task == null) {
			throw new IllegalArgumentException("Task ID Not Found");
		}
		task.setName(newName);
	}
	
	// Update task description
	public void updateTaskDescription(String taskID, String newDescription) {
		Task task = getTask(taskID);
		if (task == null) {
			throw new IllegalArgumentException("Task ID Not Found");
		}
		task.setDescription(newDescription);
	}
}
