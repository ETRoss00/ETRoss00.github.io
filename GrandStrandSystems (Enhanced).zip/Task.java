package grandstrand.contact;

import grandstrand.util.ValidateInput;

public class Task {
	// Task attributes
	private final String taskID;
	private String name;
	private String description;
	
	// Constructor to initialize task object with requirements
	public Task(String taskID, String name, String description) {
		if (!ValidateInput.isValidId(taskID, 10)) {
			throw new IllegalArgumentException("Invalid  Task ID");
		}
		if (!ValidateInput.isValidName(name, 20)) {
			throw new IllegalArgumentException("Invalid Task Name"); 
		}
		if (!ValidateInput.isValidDescription(description, 50)) {
			throw new IllegalArgumentException("Invalid Task Description");
		}
		
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
	/*// Validate user input
	private boolean validateInput(String item, int length) {
		return (item != null && item.length() <= length);
	}*/
	
	// Getters and setters for attributes
	public String getTaskID() {
		return taskID;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		if (!ValidateInput.isValidName(name, 20)) {
			throw new IllegalArgumentException("Invalid Task Name");
		}
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		if (!ValidateInput.isValidDescription(description, 50)) {
			throw new IllegalArgumentException("Invalid Task Description");
		}
		this.description = description;
	}
}
