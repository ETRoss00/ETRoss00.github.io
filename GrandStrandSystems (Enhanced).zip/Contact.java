package grandstrand.contact;

import grandstrand.util.ValidateInput;

public class Contact {
	// Contact attributes
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	// Constructor to initialize the contact object with requirements
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		if (!ValidateInput.isValidId(contactID, 10)) {
			throw new IllegalArgumentException ("Invalid contact ID");
		}
		if (!ValidateInput.isValidName(firstName, 10)) {
			throw new IllegalArgumentException ("Invalid First Name");
		}
		if (!ValidateInput.isValidName(lastName, 10)) {
			throw new IllegalArgumentException ("Invalid Last Name");
		}
		if (!ValidateInput.isValidPhone(phone)) {
			throw new IllegalArgumentException ("Invalid Phone Number");
		}
		if (!ValidateInput.isValidAddress(address, 30)) {
			throw new IllegalArgumentException ("Invalid Address");
		}
		
		this.contactID = contactID;
		this.firstName = firstName; 
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	/*// Validates input for first name, last name, and address
	private boolean validateInput(String item, int length) {
		return (item != null && item.length() <= length);
	}
	
	// Validates phone number
	private boolean validatePhone(String phone) {
		//return (phone != null && phone.matches("\\d{10}"));
	}*/
	
	// Getters and setters for attributes
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		if (!ValidateInput.isValidName(firstName, 10)) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		if (!ValidateInput.isValidName(lastName, 10)) {
			throw new IllegalArgumentException ("Invalid Last Name");
		}
		this.lastName = lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		if (!ValidateInput.isValidPhone(phone)) {
			throw new IllegalArgumentException ("Invalid Phone Number");
		}
		this.phone = phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		if (!ValidateInput.isValidAddress(address, 30)) {
			throw new IllegalArgumentException ("Invalid Address");
		}
		this.address = address;
	}
	
}
