package grandstrand.util;

public class ValidateInput {

	public static boolean isValidId(String id, int maxLength) {
        return id != null && id.length() <= maxLength;
    }

    public static boolean isValidName(String name, int maxLength) {
        return name != null && !name.trim().isEmpty() && name.length() <= maxLength;
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("\\d{10}");
    }

    public static boolean isValidAddress(String address, int maxLength) {
        return address != null && address.length() <= maxLength;
    }

    public static boolean isValidDescription(String description, int maxLength) {
        return description != null && description.length() <= maxLength;
    }

    public static boolean isValidFutureDate(java.util.Date date) {
        return date != null && date.after(new java.util.Date());
    }
}