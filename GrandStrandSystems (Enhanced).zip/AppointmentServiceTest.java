package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

import grandstrand.contact.Appointment;
import grandstrand.contact.AppointmentService;

public class AppointmentServiceTest {
	
	private AppointmentService appointmentService;
	
	@BeforeEach
	public void setup() {
		appointmentService = new AppointmentService();
	}
	
	// Test adding a valid appointment
	@Test
	public void testAddValidAppointment() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		Appointment appointment = new Appointment("12345", futureDate, "Doctor Appointment");
		assertTrue(appointmentService.addAppointment(appointment));
		assertNotNull(appointmentService.getAppointment("12345"));
	}
	
	// Test adding an appointment with an existing ID
	@Test
	public void testAddAppointmentWithExistingID() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		Appointment appointment1 = new Appointment("12345", futureDate, "Doctor Appointment");
		Appointment appointment2 = new Appointment("12345", futureDate, "Dentist Appointment");
		appointmentService.addAppointment(appointment1);
		assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
	}
	
	// Test to delete an appointment
	@Test
	public void testDeleteAppointment() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		Appointment appointment = new Appointment("12345", futureDate, "Doctor Appointment");
		appointmentService.addAppointment(appointment);
		appointmentService.deleteAppointment("12345");
		assertNull(appointmentService.getAppointment("12345"));
	}
	
	// Test deleting an appointment that doesn't exist
	@Test
	public void testDeleteNonExistentAppointment() {
		assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("00000"));
	}
	
	// Test updating a valid appointment description
	@Test
	public void testUpdateValidDescription() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		Appointment appointment = new Appointment("12345", futureDate, "Doctor Appointment");
		appointmentService.addAppointment(appointment);
		appointmentService.updateDescription("12345", "Updated Description");
		assertEquals("Updated Description", appointmentService.getAppointment("12345").getDescription());
	}
	
	// Test updating invalid description length
	@Test
	public void testUpdateInvalidDescriptionLength() {
		Date futureDate = new Date(System.currentTimeMillis() + 1000);
		Appointment appointment = new Appointment("12345", futureDate, "Doctor Appointment");
		appointmentService.addAppointment(appointment);
		assertThrows(IllegalArgumentException.class, () -> {
			appointmentService.updateDescription("12345", "This Description is Too Long and Should Throw an Exception");
		});
	}
	
	// Test updating a nonexistent appointment
	@Test
	public void testUpdateNonExistentAppointment() {
		assertThrows(IllegalArgumentException.class, () -> appointmentService.updateDescription("00000", "New Description"));
	}
}

